#pragma once
#include "client.h"
#include <QJsonArray>
#include <QtWidgets>

QString text(const QJsonObject &o, const QString &key, const QString &fallback = "—");
double number(const QJsonObject &o, const QString &key);
QString money(double value);
QString statusText(const QString &value);
QString uid();
QLabel *label(const QString &text, const QString &style = "", QWidget *parent = nullptr);
QPushButton *button(const QString &text, QObject *context, std::function<void()> action,
                    bool primary = false);
QFrame *card(const QString &title, QVBoxLayout **layout = nullptr);
QWidget *row(const QList<QWidget *> &widgets, const QList<int> &stretch = {});
void clearLayout(QLayout *layout);
void applyTheme(QApplication &app);
void showDetail(QWidget *parent, const QString &title, const QJsonObject &data);
void editForm(QWidget *parent, ApiClient *api, const QString &title, const QString &method,
              const QString &path, const QList<QPair<QString, QString>> &fields, QJsonObject values,
              std::function<void()> success);
void command(QWidget *parent, ApiClient *api, const QString &method, const QString &path,
             QJsonObject body, std::function<void(const Reply &)> success);
QWidget *picture(const QString &name, int height);

class ArtWidget : public QWidget {
    Q_OBJECT
  public:
    enum Kind { Car, TopCar, Ring, Gauge, Map, Spark, Flow };
    ArtWidget(Kind kind, QWidget *parent = nullptr);
    void setValue(double v, const QString &caption = {});
    void setStations(const QJsonArray &rows, const QString &selected = {});
    void setValues(const QList<double> &values);
  signals:
    void stationSelected(QString id);

  protected:
    void paintEvent(QPaintEvent *) override;
    void mousePressEvent(QMouseEvent *) override;

  private:
    Kind kind;
    double value = 60;
    QString caption, selected;
    QJsonArray stations;
    QList<double> values;
    QList<QPair<QPointF, QString>> hits;
    QJsonArray roads;
    double phase = 0;
    QTimer animation;
};
class DesktopWindow : public QMainWindow {
    Q_OBJECT
  public:
    DesktopWindow(ApiClient *api, CacheStore *cache, const QString &title);
    virtual void navigate(const QString &page) = 0;
    void screenshot(const QString &directory, const QStringList &pages, int delay = 1500);

  protected:
    ApiClient *api;
    CacheStore *cache;
    QWidget *root, *content;
    QVBoxLayout *outer, *body;
    QHBoxLayout *nav;
    QLabel *connection;
    QString current;
    void message(const Reply &r);
    void openUrl(const QString &path);
};
