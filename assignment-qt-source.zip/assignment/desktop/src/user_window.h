#pragma once
#include "ui.h"
class UserWindow : public DesktopWindow {
    Q_OBJECT
  public:
    UserWindow(ApiClient *api, CacheStore *cache);
    void navigate(const QString &page) override;
    void refresh();
    void login();

  private:
    void home();
    void mapPage();
    void stationPage();
    void charging();
    void statistics();
    void schedule();
    void profile();
    void history();
    void orderCommand(const QString &action);
    QJsonArray stations, chargers, orders, ledger;
    QJsonObject me, active, analytics;
    QString selectedStation;
    QTimer poll, events;
    QPointer<QObject> refreshContext;
    QPointer<QLabel> chargeEnergy, chargeCost, chargeState;
};
